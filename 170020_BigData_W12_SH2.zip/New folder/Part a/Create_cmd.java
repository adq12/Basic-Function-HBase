package HBase;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.util.Bytes;

public class Create_cmd {
	
	
	public static void main(String[] args) throws IOException
	{
		
		Configuration config = HBaseConfiguration.create();
		HBaseAdmin admin = new HBaseAdmin(config);
		HTableDescriptor des= new HTableDescriptor(Bytes.toBytes("Student_Table"));
		HColumnDescriptor hColDec = new HColumnDescriptor(Bytes.toBytes("student_courses"));
		HColumnDescriptor hColDec1 = new HColumnDescriptor(Bytes.toBytes("student_Data"));
		
		des.addFamily(hColDec);
		des.addFamily(hColDec1);
		admin.createTable(des);
		
	}

}
